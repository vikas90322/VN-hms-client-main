// src/App.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './consultation.css'
import Navbar from '../navbar/navbar';
import Sidebar from '../prescription/sidebar';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSync } from '@fortawesome/free-solid-svg-icons';

function Consultations() {
  const [data, setData] = useState([]);
  const [popupData, setPopupData] = useState(null);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  useEffect(() => {

    // Fetch data from the backend API
    axios.get('http://localhost:5000/consultation/Data')
    .then((response) => {
      setData(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const openPopup = (item) => {
    setPopupData(item);
  };

  const closePopup = () => {
    setPopupData(null);
  };
  const filterData = () => {
    if (!fromDate || !toDate) {
      // Check if both dates are selected
      alert('Please select both "From" and "To" dates.');
      return;
    }

    const filteredData = data.filter((item) => {
      const visitDate = new Date(item.lastvisitdate);
      const from = new Date(fromDate);
      const to = new Date(toDate);

      return visitDate >= from && visitDate <= to;
    });

    setData(filteredData);
  };

  const refreshData = () => {
    // Reload and show all data
    axios
      .get('http://localhost:5000/consultation/Data')
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  };
  

  return (

<>
    <Navbar/>
    <div className='two-containers-docks' >
    <Sidebar/>
  
    <div className='container-sk14'>
      <div>
        From :{''} <input type='date'
        value={fromDate}
        onChange={(e)=>setFromDate(e.target.value)}
        ></input>&nbsp;&nbsp;&nbsp;&nbsp;
         To : {''} &nbsp; <input type='date'
          value={toDate}
          onChange={(e)=>setToDate(e.target.value)}

         ></input>&nbsp;&nbsp;&nbsp;&nbsp;<button type='button' className='gosk14' onClick={filterData}>Go</button>
         &nbsp;&nbsp;&nbsp;&nbsp;
         <button type="button" className="refresh-button" onClick={refreshData}>
          <FontAwesomeIcon icon={faSync} />
        </button>
      </div>
      <div >
      <table className='tablesk14'>
        <thead>
          <tr>
            <th>ID</th>
            <th >Name</th>
            <th >Mobile Number</th>
            <th >Last Visit</th>
            <th >Actions</th> 
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              <td >{item.id}</td>
              <td >{item.name}</td>
              <td >{item.mobilenumber}</td>
              <td >{item.last_visit.slice(0,10)}</td>
              <td >
                <button className='pbsk14' onClick={() => openPopup(item)}>View</button>
              </td>
            </tr> 
          ))}
        </tbody>
      </table>
      </div>
      
      {popupData && (
        <div className="popupsk14">
          <div className="popup-contentsk14">
            <h2>Details</h2>
            <p>ID: {popupData.id}</p>
            <p>Name: {popupData.name}</p>
            <p>Mobile Number: {popupData.mobilenumber}</p>
            <p>Last Visit: {popupData.last_visit.slice(0,10)}</p>
            
            <button onClick={closePopup}>Close</button>
          </div>
        </div>
      )}
    </div>
    
    </div>
    </>
  );
}

export default Consultations;
